package com.phibs.findmyaircftstd;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.InputType;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.view.inputmethod.InputMethodManager;

import com.phibs.findmyaircftstd.R;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class MainActivity extends AppCompatActivity {

    // URL Address
    String urlLisDep = "https://flic.tap.pt/flic_ui/FLIC.aspx?id=ME-LISP1-12H_DEP";
    String urlLisArr = "https://flic.tap.pt/flic_ui/FLIC.aspx?id=CPOR-LISC1-12H_ARR";
    String urlOpoDep = "https://flic.tap.pt/flic_ui/FLIC.aspx?id=Janeiro-Dep-Tp-OPO_DEP";
    String urlOpoArr = "https://flic.tap.pt/flic_ui/FLIC.aspx?id=Janeiro-Arr-Tp-OPO_ARR";
    String urlDep, urlArr;

    EditText findData;
    EditText callsign;
    TextView searchType, rptTimeTxt, standTxt, regTxt, etaTxt, origTxt, ataTxt, eqtTxt, statusTxt, rmkInTxt, rmkOutTxt, stdTxt;
    Switch localSwitch, searchSwitch;
    ProgressDialog mProgressDialog;
    AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Find My Aircraft Parking Stand");

        // CLose any Keyboard that might be open
        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
        );
//        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
//        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
        setContentView(R.layout.activity_main);
        findData = (EditText) findViewById(R.id.findData);
        localSwitch = (Switch) findViewById(R.id.localSwitch);
        searchSwitch = (Switch) findViewById(R.id.searchSwitch);
        searchType = (TextView) findViewById(R.id.searchType);
        rptTimeTxt = (TextView) findViewById(R.id.rptTimeTxt);
        standTxt = (TextView) findViewById(R.id.standTxt);
        regTxt = (TextView) findViewById(R.id.regTxt);
        etaTxt = (TextView) findViewById(R.id.etaTxt);
        stdTxt = (TextView) findViewById(R.id.stdTxt);
        eqtTxt = (TextView) findViewById(R.id.eqtTxt);
        statusTxt = (TextView) findViewById(R.id.statusTxt);
        origTxt = (TextView) findViewById(R.id.origTxt);
        rmkInTxt = (TextView) findViewById(R.id.rmkInTxt);
        rmkOutTxt = (TextView) findViewById(R.id.rmkOutTxt);
//
//        if (searchSwitch.isChecked())
//            searchType.setText("Reg");
//        else
//            searchType.setText("TP");

        // This Block allows the user to change de Call sign using a Long Click

        dialog = new AlertDialog.Builder(this, R.style.AlertDialogTheme).create();
        callsign = new EditText(this);
        callsign.setText("TP");
        dialog.setTitle("Call sign");
        dialog.setView(callsign);
        dialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialog.setButton(DialogInterface.BUTTON_POSITIVE, "Save Text", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (callsign.getText().toString().equals(""))
                    callsign.setText("TP");
                searchType.setText(callsign.getText());
            }
        });

        searchType.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                callsign.setText(searchType.getText());
                callsign.setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)});
                callsign.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
                callsign.setHint("XXXX");
                dialog.show();
                return false;
            }
        });

//        searchType.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                callsign.setText(searchType.getText());
//                dialog.show();
//            }
//        });


        searchSwitch.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (searchSwitch.isChecked()) {
                    searchType.setText("Reg");
                    findData.setHint("CSTXX");
                    findData.setTextColor(Color.parseColor("#CCCCCC"));
                    findData.setInputType(InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
//                    findData.setFilters(new InputFilter[]{new InputFilter.LengthFilter(5)});
                } else {
                    searchType.setText(callsign.getText());
                    findData.setHint("XXXX");
                    findData.setTextColor(Color.parseColor("#CCCCCC"));
                    findData.setInputType(InputType.TYPE_CLASS_NUMBER);
//                    findData.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});
                }
            }
        });


        findData.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                findData.selectAll();
                findData.setText("");
                findData.setTextColor(Color.BLACK);
                if (searchSwitch.isChecked()) {
                    findData.setInputType(InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
                } else {
                    findData.setInputType(InputType.TYPE_CLASS_NUMBER);
                }
            }
        });

        urlDep = urlLisDep;
        urlArr = urlLisArr;
        localSwitch.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (localSwitch.isChecked()) {
                    localSwitch.setText("OPO");
                    urlDep = urlOpoDep;
                    urlArr = urlOpoArr;
                } else {
                    localSwitch.setText("LIS");
                    urlDep = urlLisDep;
                    urlArr = urlLisArr;
                }
            }
        });

        // Locate the Buttons in activity_main.xml
        final Button findBtn = (Button) findViewById(R.id.findBtn);
        // Capture button click
        findBtn.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                // Hide Keyboard after clicking FIND
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(findData.getWindowToken(), 0);
                new Find().execute();
            }
        });


    }

    // Title AsyncTask
    private class Find extends AsyncTask<Void, Void, Void> {

        String standOut = "";
        String standIn = "";
        String stand = "";
        String registrationOut = "";
        String equipment = "";
        String fltnumberOut = "";
        String eta = "";
        String sta = "";
        String std = "";
        String etd = "";
        String origin = "";
        String ata = "";
        String status = "";
        String rmkOut = "";
        String rmkIn = "";
        String searchData = findData.getText().toString();
        String reportTime = "";
        DateFormat df = new SimpleDateFormat("HH:mm");
        String timeNow = df.format(Calendar.getInstance().getTime());
        int local = 0; // 0 if its Porto, 1 if its Lisboa

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mProgressDialog = new ProgressDialog(MainActivity.this);
            mProgressDialog.setTitle("Searching, standby..");
            mProgressDialog.setMessage("Loading...");
            mProgressDialog.setIndeterminate(false);
            mProgressDialog.show();
        }

        @Override
        protected Void doInBackground(Void... params) {
            Document flightOut;
            Document flightIn;
            flightIn = null;
            flightOut = null;
            Elements fltDep;
            Elements rptTime;
            Elements fltArr;

//            String[] timeNowhourMin = timeNow.split(":");
//            int nowHour = Integer.parseInt(timeNowhourMin[0]);
//            int nowMin = Integer.parseInt(timeNowhourMin[1]);
//            int nowInt = nowHour * 60 + nowMin;

            // Connect to internet

            try {
                // Connect to the web site
                flightOut = Jsoup.connect(urlDep).get();
                flightIn = Jsoup.connect(urlArr).get();
            } catch (IOException e) {
                e.printStackTrace();
                status = "No Internet Connection";
            }

            // Create Array for Arrivals and Departure data

            String[] fltOut = new String[400];
            String[] fltIn = new String[400];

            searchData = searchData.toUpperCase();

            // Fill Departure Array with data according to Search criteria

            try {
                fltDep = flightOut.select("tr:contains(" + searchData + ") > td");
                rptTime = flightOut.select(".screenHeaderDate");
                int i = 0;

                if (fltDep.isEmpty())
                    status = "Not Found on Departures";
                else{
                    // Copy all elements from page to string fltOut
                    for (Element flight : fltDep) {
                        fltOut[i] = flight.text();
                        i++;
                    }
                }

                for (Element flight : rptTime) {
                    reportTime = flight.text();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Search on Arrival Flights

            try {
                fltArr = flightIn.select("tr:contains(" + searchData + ") > td");
                int i = 0;
                // Arrival Flights
                i = 0;
                int arrFields = 0;

                if (fltArr.isEmpty())
                    if (status.equals("Not Found on Departures"))
                        status = "Not Found";
                    else
                        status = "Not Found on Arrivals";
                else{
                    // Copy all elements from page to string fltOut
                    for (Element flight : fltArr) {
                        fltIn[i] = flight.text();
                        i++;
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            // Porto departures has one column less than Lisboa
            if (!localSwitch.isChecked())
                local = 1;

            int j = 0;
            if (searchSwitch.isChecked()) {
                // Get data from Departure Flights by Registration
                try {
                    while (!fltOut[8 + j + local].equals(""))   // atd not null
                        j = j + 25;                             // Loop crashes when j is bigger than array size
                    standOut = fltOut[5 + j];                   // Problem can be solved but it works....
//                registrationOut = fltOut[3 + j];              // using catch.
                    equipment = fltOut[4 + j];
                    fltnumberOut = fltOut[0 + j] + " " + fltOut[1 + j];
                    std = fltOut[6 + j + local];
                    etd = fltOut[7 + j + local];
                    rmkOut = fltOut[9 + j + local];
                    if (!std.equals(""))
                        std = std  + "   as   " + fltnumberOut;
                    if (!etd.equals(""))
                        etd = etd  + "   as   " + fltnumberOut;

                } catch (Exception e) {
                    e.printStackTrace();
                }
                // Get data from Arrival Flights by Registration
                try {
                    j = 0;
                    while (!fltnumberOut.equals(fltIn[10 + j]))
                            j = j + 25;
                    standIn = fltIn[5 + j];
                    origin = fltIn[2 + j];
                    sta = fltIn[6 + j];
                    eta = fltIn[7 + j];
                    ata = fltIn[8 + j];
                    rmkIn = fltIn[9 + j];
                } catch (Exception e) {
                    e.printStackTrace();
                }

            } else {
                // Get data from Departure Flights fltOut Array by Flight Number TPXXX
                int k = 0;
                try {
                    while (!fltOut[0 + k].equals(searchType.getText().toString()) || !fltOut[1 + k].equals(searchData))
                        k = k + 25;
                    standOut = fltOut[5 + k];
                    registrationOut = fltOut[3 + k];
                    equipment = fltOut[4 + k];
                    std = fltOut[6 + k + local];
                    etd = fltOut[7 + k + local];
                    rmkOut = fltOut[9 + k + local];
                    fltnumberOut = fltOut[0 + k] + " " + fltOut[1 + k];
                } catch (Exception e) {
                    e.printStackTrace();
                }

//                String[] atdhourMin = atd.split(":");
//                int atdHour = Integer.parseInt(atdhourMin[0]);
//                int atdMin = Integer.parseInt(atdhourMin[1]);
//                int atdInt = atdHour * 60 + atdMin;
//                if (atdInt < nowInt)
//                    eta = "ATD:  " + atd;
//                registrationIn = fltIn[3];
                k = 0;

                // Get data from Arrival Flights fltIn Array by Flight Number TPXXX
                try {
                    while (!fltnumberOut.equals(fltIn[10 + k]))
                        k = k + 25;
                    origin = fltIn[2 + k];
                    standIn = fltIn[5 + k];
                    sta = fltIn[6 + k];
                    eta = fltIn[7 + k];
                    ata = fltIn[8 + k];
                    rmkIn = fltIn[9 + k];
                } catch (Exception e) {
                    e.printStackTrace();
                }
//                String[] etahourMin = eta.split(":");
//                int etaHour = Integer.parseInt(etahourMin[0]);
//                int etaMin = Integer.parseInt(etahourMin[1]);
//                int etaInt = etaHour * 60 + etaMin;
//                if (nowInt < etaInt + 120) {
//                    standIn = fltIn[5];
//                    ata = fltIn[8];
//                    origin = fltIn[2];
//                }
            }
            if (!standOut.equals("") && (!standIn.equals(""))) {
                if (standOut.equals(standIn))
                    stand = standOut;
                else
                    stand = "ARR   " + standOut + "   DEP   " + standIn;
            } else {
                if (!standOut.equals(""))
                    stand = standOut;
                else
                    stand = standIn;
            }
            if (eta.equals("")) {
                eta = sta;
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            // Set title into TextView

            if (!reportTime.equals(""))
                rptTimeTxt.setText("Reported at " + reportTime.substring(8) + " LT (All Times are LT)");

            if (!registrationOut.equals("")) {
//                regTxt.setBackgroundColor(Color.parseColor("#FAE8B2"));
                regTxt.setBackgroundColor(Color.parseColor("#F0E4AE"));
                regTxt.setText("REG:   " + registrationOut);
            } else {
                regTxt.setBackgroundColor(Color.TRANSPARENT);
                regTxt.setText("");
            }
            if (!equipment.equals("")) {
                eqtTxt.setBackgroundColor(Color.parseColor("#F1ECD2"));
                eqtTxt.setText("EQUIPMENT:   " + equipment);
            } else {
                eqtTxt.setBackgroundColor(Color.TRANSPARENT);
                eqtTxt.setText("");
            }
            if (!stand.equals("")) {
                standTxt.setBackgroundColor(Color.parseColor("#F0E4AE"));
                standTxt.setText("STAND:   " + stand);
            } else {
                standTxt.setBackgroundColor(Color.TRANSPARENT);
                standTxt.setText("");
            }
            if (!origin.equals("")) {
                origTxt.setBackgroundColor(Color.parseColor("#F1ECD2"));
                origTxt.setText("ORIGIN:   " + origin);
            } else {
                origTxt.setBackgroundColor(Color.TRANSPARENT);
                origTxt.setText("");
            }
            if (!eta.equals("")) {
                etaTxt.setBackgroundColor(Color.parseColor("#F0E4AE"));
                if (!ata.equals(""))
                    etaTxt.setText("ATA:   " + ata);
                else
                    etaTxt.setText("ETA:   " + eta);
            } else {
                etaTxt.setBackgroundColor(Color.TRANSPARENT);
                etaTxt.setText("");
            }
            if (!rmkIn.equals("")) {
                rmkInTxt.setBackgroundColor(Color.parseColor("#F1ECD2"));
                rmkInTxt.setText("ARR. STATUS:   " + rmkIn);
            } else {
                rmkInTxt.setBackgroundColor(Color.TRANSPARENT);
                rmkInTxt.setText("");
            }
            if (!std.equals("")) {
                stdTxt.setBackgroundColor(Color.parseColor("#F0E4AE"));
                if (!etd.equals(""))
                    stdTxt.setText("ETD:   " + etd);
                else
                    stdTxt.setText("STD:   " + std);
            } else {
                stdTxt.setBackgroundColor(Color.TRANSPARENT);
                stdTxt.setText("");
            }
            if (!rmkOut.equals("")) {
                rmkOutTxt.setBackgroundColor(Color.parseColor("#F1ECD2"));
                rmkOutTxt.setText("DEP. STATUS:   " + rmkOut);
            } else {
                rmkOutTxt.setBackgroundColor(Color.TRANSPARENT);
                rmkOutTxt.setText("");
            }
            statusTxt.setText(status);
            mProgressDialog.dismiss();
        }
    }


}
